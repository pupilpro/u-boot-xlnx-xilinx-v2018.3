/*
 * (C) Copyright 2009
 * Stefano Babic, DENX Software Engineering, sbabic@denx.de.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */
#ifndef __SYS_PROTO_IMX5_
#define __SYS_PROTO_IMX5_

#include <asm/mach-imx/sys_proto.h>

#endif /* __SYS_PROTO_IMX5_ */
